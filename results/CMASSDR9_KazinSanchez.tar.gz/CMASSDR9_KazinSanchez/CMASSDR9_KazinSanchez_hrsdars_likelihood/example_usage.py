"""
This code gives the user basic information 
how to use the hrsdars_likelihood package.

After switching dir_main in hrsdars_likelihood.py 
to the directory that example_usage.py is in, 
and in the command line type:
--------------
python example_usage.py
--------------
You can toggle the reconstuction variable below 
from "post" to "pre". 

If all runs smooth you should get a plot that looks like 
example_profile.tiff.
"""

import hrsdars_likelihood as hdl

reconstruction="post" # Toggle between: "pre": pre-reconstruction, and "post": post-reconstruction
consensus=False       # True: consensus results of Anderson et al. (2013), False: results from clustering wedges Kazin, Sanchez et al. (2013)
if consensus: reconstruction="post"
hdlike=hdl.Likelihood_2d(reconstruction=reconstruction, consensus=consensus)

#======== setting up test Da/rs and cz/H/rs values =======
import numpy as np

drs=np.arange(5.,12.5,0.05) # test Da/rs values
hrs=np.arange(7.,17.5,0.1)  # test cz/H/rs values

#======== testing interplation performance =======
nx,ny=len(drs), len(hrs)
inferred_profile=np.zeros([nx,ny])

for ix in range(nx):
	for iy in range(ny):
		inferred_profile[ix,iy]=hdlike.interpolate_profile(drs[ix],hrs[iy]) 

# plotting results		
#levels=[0.6827, 0.9545,0.9973,0.999936]
levels=[0.6827, 0.9545,0.9973]
hdlike.obtain_profile(to_plot=True,show=False)
hdlike.visualize_profile(drs,hrs,inferred_profile,color="red",levels=levels,show=True,label="Interpolated posterior",linestyles="-")

print "example_usage, OK!"