# Name:
#	 hrsdars_likelihood.py
# Objective:
#	Managing mutual likelihood profiles of cz/H/r_s and D_A/r_s obtained by galaxy clustering.
#
# Data sets:
#	Currently based on results obtained with the BOSS DR9 anistoropic measurement (Kazin, Sanchez et al. 2013; submitted)
#   These are provided both pre- and post-reconstruction obtained with the clustering wedges RPT-based analysis (when setting consensus=False)
#	The consensus option (consensus=True) yields the Anderson et al. (2013; submitted) post-reconstruction consensus result (based on the dewiggled template).  
#
# Functions:
#	obtain_profile:      Calls in a profile
#	visualize_profile:   Plots a profile (requires the matplotlib.pyplot package)
#	interpolate_profile: Useful for cosmological constraits: given a value of cz/H/r_s, Da/r_s and requested data set, returns the likelihood function L or -2*ln(L)
# 
# Notation:
# z =  the redshift; for BOSS CMASS DR9 use z=0.57
# H =  Hubble expansion at z;  H=da/dt/a where a=1/(1+z) is the expansion factor
# Da = the proper (physical) angualar diameter distance to redshift z
# r_s= the comoving sound horizon at the end of the drag era z_d. 
# c  = the speed of light  299792.458 km/s
# Note that cz/H/r_s and Da/r_s are unitless
#
#==================================
# First Usage, IMPORTANT!
# The only setting required to get started is renaming  
# the dir_main below to the directory in which 
# this module (hrsdars_likelihood) is located.
#
# Recommended (but not obligatory)
# We recommened insuring that the operating system 
# can import the pickle package for purposes of saving 
# the interpolated likelihood in pickle format (this is not obligatory). 
# See http://docs.python.org/2/library/pickle.html for usage 
#
# For plotting purposes we recommend using the visualize_profile function 
# given here, which requires importing the matplotlib.pyplot pacakge (this is not obligatory). 
# See http://http://matplotlib.org/ for usage
#===================================
# Technical:
#	You can choose to use the result based on reconstruction 
#   (reconstruction="post"; default) or results without reconstruction (reconstruction="pre")
#
#	These profiles are obtained by analyzing the clustering wedges of CMASS DR9
#	by usage of the RPT-based template.
#	It currently only uses this data set, but the intension is to genearlize to use other sets.
#
#=====================================
# Quick application:
# After modifying dir_main, as mentioned above, at the command line type:
# ------------
# python example_usage.py
# ------------
# Assuming you have pickle working, this will generate a "interpolated_likelihood_functions"
# containing the interpolation function. If you do not have pickle the you should toggle pickleit=False in 
# function create_interpolation_function. 
# 
#
# Usage:
#	This code is generated for public use.
#	If using results in a paper, please ask the user to cite: Kazin, Sanchez et al. (2013; submitted)
#	If using the the consensus result please cite also: Anderson et al. (2013; submitted)
#
# Created by: Eyal Kazin, Swinburne University of Technology; February 27th 2013; eyalkazin@gmail.com

import numpy as np
import scipy.interpolate
import sys
import os


dir_main="/Users/eyalkazin/Work/cosmology/projects/boss_wedges/for_public/BOSScmassDR9_hrsdars_likelihood/"

class Likelihood_2d():
	def __init__(self,dataset="CMASSDR9",verbose=True, reconstruction="post", consensus=False):
		"""
		Options:
			reconstruction: "pre": pre-reconstruction result, "post": post-reconstruction result. Obtained using clustering Wedges RPT-based result of Kazin, Sanchez et al. (2013)
			consensus: Consensus result of Anderson et al. (2013) (combined result obtained using multipoles and clustering wedges with the dewiggled template)
		"""
		if dataset=="CMASSDR9": self.redshift=0.57
		else:
			self.exit_notice(notice="This code is not compatible for the input data set: "+dataset)
		
		if consensus: reconstruction="post"
		
		print "====================================="
		print "Likelihood used based on: \n"+reconstruction+"-reconstruction"
		if consensus:print "consensus result of Anderson et al. (2013)"
		else: print "clustering wedges of Kazin, Sanchez et al. (2013)"
		print "====================================="
		
		self.verbose=verbose
		if not os.path.exists(dir_main):
			self.exit_notice(notice="\n==============\n\tThe main directory needs to be set to the one containing this module hrsdars_likelihood.py.\n\tThe current seeting dir_main="+dir_main+" does not exist in you system.\n\tPlease update for usage.")
		
		
		
		if reconstruction=="post":
			if consensus:
				#self.prefix="grid_consensus_rec_spline"
				self.prefix="HzDaprofile_dewiggled_consensus_postRec_T0.15"
			else:
				self.prefix="HzDaprofile_rpt_wedges_postRec_T0.15"
		else:
			self.prefix="HzDaprofile_rpt_wedges_preRec_T0.15"
		self.consensus=consensus
	def obtain_profile(self,reconstruction="post",to_plot=True,show=True): 
		"""
		Calls in the likelihood profile profile
		
		Options:
			to_plot: plot the profile
			to_show: applies plt.show() in call	
		"""
		nx, ny= 80, 40
		
		profile_file=dir_main+"/likelihood_functions/"+self.prefix+".txt"
			
		if self.verbose: print "reading in: "+profile_file
		the_profile=np.genfromtxt(profile_file)
		dars_values_toolong=the_profile[:,0]           # alphaT bin values
		czhrs_values_toolong=the_profile[:,1]           # alphaL bin values
		twoD_likelihood_1dformat=the_profile[:,2]    # P(alphaT,alphaL)
		
		# ==== Converting the 1D representation to 2D ===
		dars_values=dars_values_toolong[range(0,nx*ny,ny)]
		czhrs_values=czhrs_values_toolong[0:ny]
		
		twoD_likelihood_grid=np.zeros([nx,ny])
		counter=0
		for ix in range(nx):
			for iy in range(ny):
				twoD_likelihood_grid[ix,iy]=twoD_likelihood_1dformat[counter]
				counter+=1
		if self.consensus: # Normalization required for the consensus file, not for the clustering wedges file. Not essential, just for plotting aesthetics
			twoD_likelihood_grid/=0.0343484055179
		# ==== Plotting Option ====
		if to_plot:
			self.visualize_profile(dars_values,czhrs_values,twoD_likelihood_grid,show=show,label="Input posterior")
		
		self.dars_values =dars_values
		self.czhrs_values=czhrs_values
		self.twoD_likelihood_grid=twoD_likelihood_grid
					
	def visualize_profile(self,x,y,Lxy,color="blue",show=True,levels=[0.6827, 0.9545,0.9973],label=None,linestyles="-"):
		"""
		Plots the 2D probability function
		#levels=[0.6827, 0.9545,0.9973,0.999936,1.]
		"""
		try: 
			import matplotlib.pyplot as plt
		except:
			self.exit_notice(notice="==================\n Your system cannot currently import the matplotlib.pyplot package.\n You may bypass this option by setting to_plot=False.\n For more information on matplotlib see http://http://matplotlib.org/")			
		xlabel=r"$D_{\rm A}/r_{\rm s}$"
		ylabel=r"$cz/H/r_{\rm s}$"
		
		CS=plt.contour(x,y,1.-Lxy.T,levels=levels,colors=color,linewidths=2,linestyles=linestyles)
		plt.clabel(CS, inline=1, fontsize=5)
		plt.xlabel(xlabel,fontsize=18.)
		plt.ylabel(ylabel,fontsize=18.)
		
		if label:
			CS.collections[0].set_label(label)
		
		if show:
			plt.legend(frameon=False,loc='lower left')
			plt.show()
		
	def interpolate_profile(self,requested_dars,requested_czhrs):
		"""
		Returns the probability of the requested Da/rs and cz/H/rs
		requested_dars: Da/rs
		requested_czhrs: cz/H/rs
		
		This calculation is done through interpolation
		"""
		try: 
			self.probfunc_hrs_dArs
		except:
			self.create_interpolation_function()
		requested_param_prob=self.probfunc_hrs_dArs(requested_dars,requested_czhrs) 
		
		#if requested_param_prob<0.:
		#	requested_param_prob=np.array([0.])
		return requested_param_prob  
		
	def create_interpolation_function(self,pickleit=True):
		"""
		Creates an interpolation function.
		We recommened to use pickle to save interpolation file.
		
		pickleit: True: use pickle option; False: do not
		"""
		interpolkind="quintic" #"cubic"

		if pickleit:
			#interpole2d_file+="interpolation_func_"+interpolkind+".pickle"
			dir_interpol=dir_main+"/interpolated_likelihood_functions/"
			if not os.path.exists(dir_interpol):
				os.system("mkdir "+dir_interpol)
				print "===========\ncreated the path "+dir_interpol+"\n which stores the interoplated likelihood function in a pickle format.\n==========="
			interpole2d_file=dir_interpol+self.prefix+"_interpolation.pickle" 
			try:
				import pickle
			except:
				self.exit_notice(notice="==================\n Your system cannot currently import the pickle package.\n The advantage of saving into pickle is to save the interpolation, which takes a while to calculate.\n You may bypass this option by setting pickleit=False.\n For more information on pickle see http://docs.python.org/2/library/pickle.html")
			if os.path.exists(interpole2d_file):
				print "opening file: "+interpole2d_file
				the_file=open(interpole2d_file,'rb')
				self.probfunc_hrs_dArs=pickle.load(the_file)
				#print "file open!"
			else:
				print "File NOT found, so generating: "+interpole2d_file
				print "This might take a while ... (pickleit is set to True, so the interpolation function will be saved, for much quicker future usage)"
				try:
					self.dars_values
				except:
					self.obtain_profile(show=True)
				###self.probfunc_hrs_dArs=scipy.interpolate.interp2d(self.dars_values,self.czhrs_values, self.twoD_likelihood_grid.T, kind=interpolkind)
				self.probfunc_hrs_dArs=scipy.interpolate.RectBivariateSpline(self.dars_values,self.czhrs_values, self.twoD_likelihood_grid) # much quicker, and appears more reliable than interp2d
				the_file=open(interpole2d_file,'wb') 
				pickle.dump(self.probfunc_hrs_dArs,the_file)
				print "created: "+interpole2d_file
			the_file.close()
		else:
			try:
				self.dars_values
			except:
				self.obtain_profile()
			print "This might take a while ... (pickleit is currently set to False. If pickleit is set to True, the interpolation function will be saved, for much quicker future usage)"
			self.probfunc_hrs_dArs=scipy.interpolate.interp2d(self.dars_values,self.czhrs_values, self.twoD_likelihood_grid.T, kind=interpolkind)
		
	def exit_notice(self,notice=None):
		if notice: print notice
		print "purpose exit from hrsdars_likelihood.py"
		sys.exit(1)